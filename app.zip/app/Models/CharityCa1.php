<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class CharityCa1 extends Model
{
    protected $table='charities_ca1';

}
