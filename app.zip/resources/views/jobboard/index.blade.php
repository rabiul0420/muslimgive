@extends('jobboard.jobseekers.common.master')
@section('content')
	{!! csrf_field() !!}
	<div class="main-container jobboard_section">
        <div class="container">
			<div class="content-box ">
				<div class="row row-featured">
					<div class="col-lg-12  box-title detail-box-title">
						<div class="inner">
							<h2>
								<span class="title-3"><b>Featured Job</b></span>
								<a href="{{ url('job-list') }}" class="sell-your-item">{{ t('View more') }} <i class="  icon-th-list"></i></a>
							</h2>
						</div>
					</div>





					<div style="clear: both"></div>

					<div class=" relative content featured-list-row featured-list-row-jobs clearfix">
						<nav class="slider-nav has-white-bg nav-narrow-svg">
							<a class="prev">
								<span class="nav-icon-wrap"></span>
							</a>
							<a class="next">
								<span class="nav-icon-wrap"></span>
							</a>
						</nav>
						<div class="no-margin featured-list-slider-jobs featured-list-slider">
							<?php foreach($jb_feacher as $key => $feacher): ?>
								<div class="item">
									<a href="#">
										<span class="item-carousel-thumb">
										   <img class="img-responsive" src="{{ url($feacher->company_logo) }}" alt="" data-no-retina="" style="border: 1px solid #e7e7e7; margin-top: 2px;">
										</span>
										<span class="item-name"><a href="{{url('job-detail').'/'.$feacher->id}}">{{$feacher->job_title}}</a></span>

									</a>
								</div>
							<?php endforeach; ?>
						</div>
					</div>
				</div>
			</div>

			<div class="row">
				<div class="col-md-12 col-sm-12">
					<div class="row search-job-section">

						<div class="col-md-9">

							<div class="inner-box">
								<div class="box-title detail-box-title">
									<h2>
										<i class="fa fa-search yewllo"></i> <span class="title-3"><b>Find Your Right Job </b></span>
									</h2>
								</div>

								<div class="search-row-wrapper">
									<form id="seach" name="search" action="{{url('employer-job-list-search')}}" method="GET">
                                            <div class="ads-search">
                                                <div class="row">
                                                    <div class="col-xs-10 col-md-10">
                                                        <input type="text" required  name="job_title" class="form-control keyword" placeholder="Search By Kywords">
                                                    </div>
                                                    <div class="col-xs-2 col-md-2">
                                                        <button class="btn btn-block btn-primary search_form"><i class="fa fa-search"></i></button>
                                                    </div>
                                                </div>
                                            </div>
									</form>
								</div>
							</div>





							<!-- All Category job-->
							<div class="graduate-category">
								<div class="box-title detail-box-title">
										<h2>
											<i class="fa fa-th-list"></i> <span class="title-3"><b>All Category Jobs </b></span>
										</h2>
								</div>

								<div class="all-categories">
									<div class="row">
										<div class="col-md-4">
										   <ul>

												<?php foreach($jb_categories as $k=>$row){ if($k%3==0){ ?>
												<li>
													<i class="fa fa-angle-right"></i> <a  href="{{url('employer-job-list-category').'/'.$row->id.'/0'}}" title="Accounting/Finance"><i class="icon-angle-right"></i>{{$row->name}} <span></span></a>
												</li>
												<?php } } ?>

											</ul>
										</div>
										<div class="col-md-4">
										   <ul>

												<?php foreach($jb_categories as $k=>$row){ if($k%3==1){ ?>
												<li>
													<i class="fa fa-angle-right"></i> <a  href="{{url('employer-job-list-category').'/'.$row->id.'/0'}}" title="Accounting/Finance"><i class="icon-angle-right"></i>{{$row->name}} <span></span></a>
												</li>
												<?php } } ?>

											</ul>
										</div>
										<div class="col-md-4">
										   <ul>

												<?php foreach($jb_categories as $k=>$row){ if($k%3==2){ ?>
												<li>
													<i class="fa fa-angle-right"></i> <a  href="{{url('employer-job-list-category').'/'.$row->id.'/0'}}" title="Accounting/Finance"><i class="icon-angle-right"></i>{{$row->name}} <span></span></a>
												</li>
												<?php } }  ?>
											</ul>
										</div>
									</div>
								</div>
							</div>

							<!-- Graduate job-->

							<div class="all-jobs">
								<div id="hotjobsDiv">
										<div class="box-title detail-box-title">
											<h2>
												<i class="fa fa-graduation-cap"></i> <span class="title-3"><b>Graduate Jobs </b></span>
											</h2>
										</div>

										<?php $jb_graduate_no = count($jb_graduate); ?>
										<?php if($jb_graduate_no){ ?>
										<div class="row hj-row grey">
												<?php foreach($jb_graduate as $key=>$row){ if($key<=2){ ?>
												<div class="col-md-4 col-sm-4 col-xs-12 c-card br">
													<div class="row">
														<div class="hotJobsCompany">
															<div class="col-md-3 pr">
																<div class="companyLogo">
																	<img width="40" height="40" src="{{ url($row->company_logo) }}" alt="">
																</div>
															</div>
															<div class="col-md-9 pl">
																<div class="companyDetails">
																	<h5>{{$row->company_name}}</h5>
																	<ul>
																		<li><a href="{{url('job-detail').'/'.$row->id}}"  title="Deputy Manager - Medical Advocacy &amp; Education ">{{$row->job_title}}</a></li>
																		</ul>
																</div>
															</div>
														</div>
													</div>
												</div>
												<?php } } ?>
										</div>
										<?php } if($jb_graduate_no>3){ ?>


										<div class="row hj-row" style="height: auto;">

											<?php foreach($jb_graduate as $key=>$row){ if(2<$key && $key<=5){ ?>
												<div class="col-md-4 col-sm-4 col-xs-12 c-card br">
													<div class="row">
														<div class="hotJobsCompany">
															<div class="col-md-3 pr">
																<div class="companyLogo">
																	<img width="40" height="40" src="{{ url($row->company_logo) }}" alt="">
																</div>
															</div>
															<div class="col-md-9 pl">
																<div class="companyDetails">
																	<h5>{{$row->company_name}}</h5>
																	<ul>
																		<li><a href="{{url('job-detail').'/'.$row->id}}"  title="">{{$row->job_title}}</a></li>
																	</ul>
																</div>
															</div>
														</div>
													</div>
												</div>
												<?php } } ?>


										</div>
										<?php } if($jb_graduate_no>6){ ?>
										<div class="row hj-row grey">
												<?php foreach($jb_graduate as $key=>$row){ if($key<=2){ ?>
												<div class="col-md-4 col-sm-4 col-xs-12 c-card br">
													<div class="row">
														<div class="hotJobsCompany">
															<div class="col-md-3 pr">
																<div class="companyLogo">
																	<img width="40" height="40" src="{{ url($row->company_logo) }}" alt="">
																</div>
															</div>
															<div class="col-md-9 pl">
																<div class="companyDetails">
																	<h5>{{$row->company_name}}</h5>
																	<ul>
																		<li><a href="{{url('job-detail').'/'.$row->id}}"  title="Deputy Manager - Medical Advocacy &amp; Education ">{{$row->job_title}}</a></li>
																		</ul>
																</div>
															</div>
														</div>
													</div>
												</div>
												<?php } } ?>
										</div>

										<?php } ?>




								</div>
								<input type="hidden" value="1" id="hHotjobidcount">
							</div>


						</div>
						<div class="col-md-3 sidebar-left">
							<div class="box-title text-center">
							   <h2>Govt jobs</h2>
							</div>
							<div class="graduate-left-category">
								<h4>GOVT JOBS</h4>
								<ul>
									<?php foreach($jb_govt as $key => $feacher): ?>
									<li><a href="{{url('job-detail').'/'.$feacher->id}}">{{$feacher->job_title}}</a></li>
									<?php endforeach ?>
								</ul>
							</div>
						</div>
					</div>
				</div>
			</div>





			<div class="row">
    			<div class="col-md-12 col-sm-12">




    		    <div class="skilled-job-category">


					<div class="box-title detail-box-title">
											<h2>
												<i class="fa fa-cogs"></i> <span class="title-3"><b>Skilled jobs </b></span>
											</h2>
					</div>
                    <div class="skilled-category">
						<div class="row">
							<div class="col-md-3">
								<ul>
									<?php foreach($jb_categories as $k=>$row){ if($k%4==0){ ?>
									<li>
										<i class="fa fa-angle-right"></i> <a  href="{{url('employer-job-list-category').'/'.$row->id.'/3'}}" title="Accounting/Finance"><i class="icon-angle-right"></i>{{$row->name}} <span></span></a>
									</li>
									<?php } } ?>
								</ul>
							</div>
							<div class="col-md-3">
							    <ul>
									<?php foreach($jb_categories as $k=>$row){ if($k%4==1){ ?>
									<li>
										<i class="fa fa-angle-right"></i> <a  href="{{url('employer-job-list-category').'/'.$row->id.'/3'}}" title="Accounting/Finance"><i class="icon-angle-right"></i>{{$row->name}} <span></span></a>
									</li>
									<?php } } ?>
								</ul>
							</div>
							<div class="col-md-3">
							   <ul>
									<?php foreach($jb_categories as $k=>$row){ if($k%4==2){ ?>
									<li>
										<i class="fa fa-angle-right"></i> <a  href="{{url('employer-job-list-category').'/'.$row->id.'/3'}}" title="Accounting/Finance"><i class="icon-angle-right"></i>{{$row->name}} <span></span></a>
									</li>
									<?php } } ?>
								</ul>
							</div>
							<div class="col-md-3">
							   <ul>
									<?php foreach($jb_categories as $k=>$row){ if($k%4==3){ ?>
									<li>
										<i class="fa fa-angle-right"></i> <a  href="{{url('employer-job-list-category').'/'.$row->id.'/3'}}" title="Accounting/Finance"><i class="icon-angle-right"></i>{{$row->name}} <span></span></a>
									</li>
									<?php } } ?>
								</ul>
							</div>



						 </div>
					</div>
	            </div>


                </div>

            </div>




		</div>



















	</div>
@endsection


@section('javascript')
	@parent
	<script src="{{ url('/assets/js/owl.carousel.min.js') }}"></script>
	<script src="{{ url('/assets/js/script.js?time=' . time()) }}"></script>
	<script src="{{ url('assets/plugins/bxslider/jquery.bxslider.min.js') }}"></script>
	<script>
		var stateId = '<?php echo (isset($city)) ? $country->get('code') . '.' . $city->subadmin1_code : '0' ?>';

		/* JS translation */
		var lang = {
			loginToSaveAd: "@lang('global.Please log in to save the Ads.')",
			loginToSaveSearch: "@lang('global.Please log in to save your search.')",
			confirmationSaveSearch: "@lang('global.Search saved successfully !')",
			confirmationRemoveSaveSearch: "@lang('global.Search deleted successfully !')"
		};

		$('.bxslider').bxSlider({
			pagerCustom: '#bx-pager',
			controls: true,
			nextText: " @lang('global.Next') &raquo;",
			prevText: "&laquo; @lang('global.Previous') "
		});

	</script>

@endsection