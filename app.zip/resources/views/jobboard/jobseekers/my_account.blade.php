@extends('jobboard.jobseekers.common.master')
@section('content')
	<div class="main-container">
		<div class="container">
			<div class="row">

				<!-- Sidebar -->
				<div class="col-md-3 sidebar-left  hidden-xs">
				    @include('jobboard.common.seeker_panel')	                                   									  					 
			    </div>
			

				
				
				<div class="col-md-9 col-sm-12">

					<div class="panel">
						<div class="panel-heading panel-heading-01"><i class="glyphicon glyphicon-eye-open icon-padding"></i>My Account
						</div>
						<div class="panel-body panel-body-02">

						
							   
						 
					    </div>
					</div>
				</div>
				
				
				
				
				
				
				
				
				
				
				
				
				
				
			</div>
		</div>
	</div>
@endsection


