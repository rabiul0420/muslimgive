                    <div class="box-title text-center"> 
					   <h2>My Account</h2>
					</div>
					<div class="">
						<div class="category-links account-panel">
							<ul>
				
								<li>
									<i class="icon-home yewllo"></i>
									<a  href="{{url('my-account-seeker')}}">
										My Account
									</a>
								</li>
								
								<!--<li>
									<i class="fa fa-eye yewllo" aria-hidden="true"></i>
									<a href="{{url('resume-view')}}">
										View Resume
									</a>
								</li>-->
								<!--<li>
									<i class="fa fa-pencil-square-o yewllo" aria-hidden="true"></i>
									<a href="{{url('resume-view-step1')}}">
										Create/Edit Resume
									</a>
								</li>-->
							
								
								<li>
									<i class="fa fa-upload yewllo" aria-hidden="true"></i>
									<a href="{{url('resume-upload')}}">
										Upload Resume  
									</a>
								</li>
								<!--<li>
									<img src="http://localhost/classified/uploads/app/categories/default/fa-home.png" alt="img" data-no-retina="">
									<a href="{{url('resume-email')}}">
										Email Resume
									</a>
								</li> -->
								
								<li>
									<i class="fa fa-hand-o-right yewllo" aria-hidden="true"></i>
									<a href="{{url('application-job-employee')}}">
										Application Job  
									</a>
								</li>
							
								<li>
									<i class="fa fa-sign-out yewllo" aria-hidden="true"></i>
									<a href="{{url('seekers-logout')}}">
										Sign Out
									</a>
								</li>
								
							</ul>
						</div>
					</div>