
				    <div class="box-title text-center"> 
					   <h2>Employer Panel</h2>
					</div>
					<div class="">
						<div class="category-links account-panel">
							<ul>
				
								<li>
									<i class="icon-home yewllo"></i>
									<a href="{{url('account')}}">
										@lang('global.Personal Home')
									</a>
								</li>
								<li>
									<i class="fa fa-hand-o-right yewllo"></i>
									<a href="{{url('post-new-job')}}">
										Post New Job
									</a>
								</li>
								<li>
									<i class="fa fa-pencil-square-o yewllo"></i>
									<a href="{{url('employer-job-list')}}">
										Edit All Job
									</a>
								</li>
								<li>
									<i class="fa fa-hand-o-right yewllo"></i>
									<a href="{{url('employer-job-application-list')}}">
										Applications  
									</a>
								</li>
								
								<li>
									<i class="fa fa-pencil-square-o yewllo"></i>
									<a href="{{url('employer-edit-profile')}}">
										Company Profile  
									</a>
								</li>
								<li>
									<i class="fa fa-sign-out yewllo"></i>
									<a href="{{url('logout')}}">
										Sign Out
									</a>
								</li>
								
							</ul>
						</div>
					</div>	                                   									  					 
			   