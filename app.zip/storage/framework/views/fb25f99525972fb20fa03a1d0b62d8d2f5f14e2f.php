<?php $__env->startSection('content'); ?>
    <div id="main" role="main">

        <!-- RIBBON -->
        <div id="ribbon">
				<span class="ribbon-button-alignment">
					<span id="refresh" class="btn btn-ribbon" data-action="resetWidgets" data-title="refresh" rel="tooltip" data-placement="bottom" data-original-title="<i class='text-warning fa fa-warning'></i> Warning! This will reset all your widget settings." data-html="true">
						<i class="fa fa-refresh"></i>
					</span>
				</span>
                <ol class="breadcrumb">
                    <li>Home</li><li>System Settings</li>
                </ol>
        </div>
        <!-- END RIBBON -->

        <!-- MAIN CONTENT -->
        <div id="content">
            <h3>System Setting</h3>
            <hr/>
            <?php  $tab = isset($_GET['tab'])?$_GET['tab']:'Basic' ?>
            <div class="col-xs-3">
                <ul class="nav nav-tabs tabs-left">
                    <li class="<?php echo ($tab=='Basic')?'active':'' ?>"><a href="#basic" data-toggle="tab">Basic</a></li>
                    <li class="<?php echo ($tab=='Contact')?'active':'' ?>"><a href="#contact" data-toggle="tab">Contact</a></li>
                    <li class="<?php echo ($tab=='Social')?'active':'' ?>"><a href="#social" data-toggle="tab">Social</a></li>
                    <li class="<?php echo ($tab=='Misc')?'active':'' ?>"><a href="#misc" data-toggle="tab">Misc</a></li>
                    
                </ul>
            </div>
            <div class="col-xs-9">
                <!-- Tab panes -->
                <?php echo Form::open(['url'=>'admin/system-settings','files'=>true]); ?>

                <input type="hidden" name="tab" value="<?php echo e($tab); ?>">
                <div class="tab-content">
                                     
                    <div class="tab-pane <?php echo ($tab=='Basic')?'active':'' ?>" id="basic">
                        <div class="form-group">
                            <label>Site Title</label>
                            <input type="text" class="form-control" value="<?php echo e(settings('site_title', $settings)); ?>" name="data[site_title]">
                        </div>
                        <div class="form-group">
                            <label>Slogan</label>
                            <input type="text" class="form-control" value="<?php echo e(settings('site_slogan', $settings)); ?>" name="data[site_slogan]">
                        </div>


                        <div class="form-group">
                            <label>Favicon <?php if(settings('site_favicon', $settings)): ?> <a href="#" data-toggle="modal" data-target="#FaviconModal">View Favicon</a> <?php endif; ?></label>
                            <div class="input-group">
                                <input id="Favicon" readonly  type="text" class="form-control" value="<?php echo e(settings('site_favicon', $settings)); ?>" name="data[site_favicon]">
                                <a data-input="Favicon" class="lfm iframe-btn input-group-addon bg-success no-border"><i class="icon fa fa-upload"></i></a>
                                <a onclick="$(this).parent().find('#Favicon').val('');" href="javascript:" class="input-group-addon bg-danger no-border"><i class="icon fa fa-times-circle"></i></a>
                            </div>
                        </div>

                        <div class="form-group">
                            <label>Logo <?php if(settings('site_logo', $settings)): ?> <a href="#" data-toggle="modal" data-target="#LogoModal">View Logo</a> <?php endif; ?></label>
                            <div class="input-group">
                                <input id="Logo" readonly type="text" class="form-control" value="<?php echo e(settings('site_logo', $settings)); ?>" name="data[site_logo]">
                                <a data-input="Logo" class="lfm iframe-btn input-group-addon bg-success no-border"><i class="icon fa fa-upload"></i></a>
                                <a onclick="$(this).parent().find('#Logo').val('');" href="javascript:" class="input-group-addon bg-danger no-border"><i class="icon fa fa-times-circle"></i></a>
                            </div>
                        </div>

                        

                    </div>

                                         
                    <div class="tab-pane <?php echo ($tab=='Contact')?'active':'' ?>" id="contact">
                        <div class="form-group">
                            <label>Phone</label>
                            <input type="number" class="form-control" value="<?php echo e(settings('site_phone', $settings)); ?>" name="data[site_phone]">
                        </div>

                        <div class="form-group">
                            <label>Phone 2</label>
                            <input type="number" class="form-control" value="<?php echo e(settings('site_phone2', $settings)); ?>" name="data[site_phone2]">
                        </div>

                        <div class="form-group">
                            <label>Email</label>
                            <input type="email" class="form-control" value="<?php echo e(settings('site_email', $settings)); ?>" name="data[site_email]">
                        </div>

                        <div class="form-group">
                            <label>Email 2</label>
                            <input type="email" class="form-control" value="<?php echo e(settings('site_email2', $settings)); ?>" name="data[site_email2]">
                        </div>

                        <div class="form-group">
                            <label>Address</label>
                            <input type="text" class="form-control" value="<?php echo e(settings('site_address', $settings)); ?>" name="data[site_address]">
                        </div>

                        <div class="form-group">
                            <label>Latitude</label>
                            <input type="text" class="form-control" value="<?php echo e(settings('site_lat', $settings)); ?>" name="data[site_lat]">
                        </div>

                        <div class="form-group">
                            <label>Longitude</label>
                            <input type="text" class="form-control" value="<?php echo e(settings('site_lon', $settings)); ?>" name="data[site_lon]">
                        </div>

                    </div>

                                       
                    <div class="tab-pane <?php echo ($tab=='Social')?'active':'' ?>" id="social">
                        <div class="form-group">
                            <label>Facebook</label>
                            <input type="text" class="form-control" value="<?php echo e(settings('facebook', $settings)); ?>" name="data[facebook]">
                        </div>
                        <div class="form-group">
                            <label>Twitter</label>
                            <input type="text" class="form-control" value="<?php echo e(settings('twitter', $settings)); ?>" name="data[twitter]">
                        </div>
                        
                        <div class="form-group">
                            <label>Google Plus</label>
                            <input type="text" class="form-control" value="<?php echo e(settings('google_plus', $settings)); ?>" name="data[google_plus]">
                        </div>
                        <div class="form-group">
                            <label>Youtube</label>
                            <input type="text" class="form-control" value="<?php echo e(settings('youtube', $settings)); ?>" name="data[youtube]">
                        </div>
                        
                        
                    </div>


                                           
                    <div class="tab-pane <?php echo ($tab=='Misc')?'active':'' ?>" id="misc">
                        <div class="form-group">
                            <label>Extra Day of Passport for Umrah</label>
                            <input type="number" class="form-control" value="<?php echo e(settings('extra_day_passport_umrah', $settings)); ?>" name="data[extra_day_passport_umrah]">
                        </div>
                    </div>
                                    

                    <button type="submit" class="btn btn-primary">Update</button>
                </div>
                <?php echo Form::close(); ?>

            </div>
            <div class="clearfix"></div>
            <br>

        </div>
        <!-- END MAIN CONTENT -->

    </div>



    <!-- Modal -->
                        
    <div id="FaviconModal" class="modal fade" role="dialog">
        <div class="modal-dialog">
            <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title">Favicon Icom</h4>
                </div>
                <div class="modal-body">
                    <img src="<?php echo e(asset(settings('site_favicon', $settings))); ?>" alt="">
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                </div>
            </div>

        </div>
    </div>

    
    <div id="LogoModal" class="modal fade" role="dialog">
        <div class="modal-dialog">
            <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title">Logo</h4>
                </div>
                <div class="modal-body">
                    <img src="<?php echo e(asset(settings('site_logo', $settings))); ?>" alt="">
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                </div>
            </div>

        </div>
    </div>

    
    <div id="HeaderLogo1Modal" class="modal fade" role="dialog">
        <div class="modal-dialog">
            <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title">Header Logo 1</h4>
                </div>
                <div class="modal-body">
                    <img src="<?php echo e(asset(settings('header_logo_1', $settings))); ?>" alt="">
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                </div>
            </div>

        </div>
    </div>

    
    <div id="HeaderLogo2Modal" class="modal fade" role="dialog">
        <div class="modal-dialog">
            <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title">Header Logo 2</h4>
                </div>
                <div class="modal-body">
                    <img src="<?php echo e(asset(settings('header_logo_2', $settings))); ?>" alt="">
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                </div>
            </div>

        </div>
    </div>

    
    <div id="FooterLogo1Modal" class="modal fade" role="dialog">
        <div class="modal-dialog">
            <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title">Footer Logo 1</h4>
                </div>
                <div class="modal-body">
                    <img src="<?php echo e(asset(settings('footer_logo_1', $settings))); ?>" alt="">
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                </div>
            </div>

        </div>
    </div>

    
    <div id="FooterLogo2Modal" class="modal fade" role="dialog">
        <div class="modal-dialog">
            <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title">Footer Logo 2</h4>
                </div>
                <div class="modal-body">
                    <img src="<?php echo e(asset(settings('footer_logo_2', $settings))); ?>" alt="">
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                </div>
            </div>

        </div>
    </div>



<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>


    <!--<script src="http://ajax.googleapis.com/ajax/libs/jqueryui/1.10.3/jquery-ui.min.js"></script> -->

    <script src="<?php echo e(asset('js/libs/jquery-ui.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/plugin/bootstrap-timepicker/bootstrap-timepicker.min.js')); ?>"></script>
    <script type="text/javascript">

        // DO NOT REMOVE : GLOBAL FUNCTIONS!

        $(document).ready(function() {

            $('.tabs-left a').click(function(){
               var tabtext = $(this).text();
               $('[name="tab"]').val(tabtext);
            })


            $.fn.filemanager = function(type, options) {
                type = type || 'file';

                this.on('click', function(e) {
                    var route_prefix = (options && options.prefix) ? options.prefix : '/laravel-filemanager';
                    localStorage.setItem('target_input', $(this).data('input'));
                    localStorage.setItem('target_preview', $(this).data('preview'));
                    window.open(route_prefix + '?type=' + type, 'FileManager', 'width=900,height=600');
                    window.SetUrl = function (url, file_path) {
                        //set the value of the desired input to image url
                        var target_input = $('#' + localStorage.getItem('target_input'));
                        target_input.val(file_path).trigger('change');

                    };
                    return false;
                });
            }
            $('.lfm').filemanager('image');


            $('#timepicker').timepicker();
            $('#timepicker1').timepicker();

            $(".datepicker").datepicker({
                changeMonth: true,
                numberOfMonths: 1,
                prevText: '<i class="fa fa-chevron-left"></i>',
                nextText: '<i class="fa fa-chevron-right"></i>',
                dateFormat: 'yy-mm-dd',

            });



        })

    </script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>