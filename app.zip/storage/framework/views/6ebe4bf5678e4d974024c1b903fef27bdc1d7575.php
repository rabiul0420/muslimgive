<?php $__env->startSection('content'); ?>

    <div id="main" role="main">
        <div id="ribbon">
				<span class="ribbon-button-alignment">
					<span id="refresh" class="btn btn-ribbon" data-action="resetWidgets" data-title="refresh"  rel="tooltip" data-placement="bottom" data-original-title="<i class='text-warning fa fa-warning'></i> Warning! This will reset all your widget settings." data-html="true">
						<i class="fa fa-refresh"></i>
					</span>
				</span>
                <ol class="breadcrumb">
                    <li>Home</li><li>Edit Role</li>
                </ol>
        </div>

        <div id="content">
            <div class="row">
                <div class="col-xs-12 col-sm-7 col-md-7 col-lg-4">
                    <h1 class="page-title txt-color-blueDark">
                        <i class="fa fa-edit fa-fw "></i>
                        Roles
                        <span>> Edit Role</span>
                    </h1>
                </div>
            </div>

            <?php if(Session::has('message')): ?>
                <div class="allert-message alert-success-message pgray  alert-lg" role="alert">
                    <p class=""> <?php echo e(Session::get('message')); ?></p>
                </div>
            <?php endif; ?>
            <!-- widget grid -->
            <section id="widget-grid" class="">

                    <article class="">
                        <div class="jarviswidget" id="wid-id-1" data-widget-colorbutton="false" data-widget-editbutton="false" data-widget-custombutton="false">
                            <header>
                                <span class="widget-icon"> <i class="fa fa-edit"></i> </span>
                                <h2>Add Roles </h2>
                            </header>
                            <div>
                                <div class="widget-body">
                                    <?php echo Form::open(['action'=>['Admin\RolesController@update',$role->id],'method'=>'PUT','files'=>true]); ?>

                                    <div class="row">

                                        <div class="col-md-10">

                                            <div class="form-group">
                                                <label>Name</label>
                                                <input type="text" class="form-control" required value="<?php echo e($role->name); ?>" name="name">
                                            </div>


                                            <h3>Permissions</h3>

                                            <div class="col-xs-12 form-group">
                                                <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <div class="checkbox">
                                                        <label><input name="permission[]" <?php echo in_array($row->id,$exist_permission)?'checked':'' ?> value="<?php echo e($row->id); ?>" type="checkbox">
                                                            <?php echo e($row->name); ?>

                                                        </label>
                                                    </div>
                                                    <div style="padding-left: 20px" class="row">
                                                        <div class="">
                                                            <?php $__currentLoopData = $row->child; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <div class="col-md-3">
                                                                    <div class="checkbox">
                                                                        <label><input class="child-permission parent-<?php echo e($row->id); ?>" data-parent_id="<?php echo e($row->id); ?>" name="permission[]" <?php echo in_array($child->id,$exist_permission)?'checked':'' ?> value="<?php echo e($child->id); ?>" type="checkbox">
                                                                            <?php echo e($child->name); ?>

                                                                        </label>
                                                                    </div>
                                                                </div>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </div>

                                                    </div>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </div>

                                        </div>

                                    </div>
                                        <footer>
                                            <button type="submit" class="btn btn-primary">Update</button>
                                            <button type="button" class="btn btn-primary" onclick="window.history.back();">Back</button>
                                        </footer>
                                    <?php echo Form::close(); ?>

                                </div>
                            </div>
                        </div>
                    </article>

            </section>



        </div>


    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('js'); ?>
<script>
    $(function () {


        $('[name="permission[]"]').on('click', function() {
            var parent_id = $(this).val();
            $(".parent-"+parent_id).prop('checked', $(this).prop("checked"));
        })

        $('.child-permission').on('click', function() {

            var child_parent_id = $(this).attr("data-parent_id");

            if($('.parent-'+child_parent_id+':checked').length){
                $("input[value='" + child_parent_id + "']").prop('checked', true);
            }else{
                $("input[value='" + child_parent_id + "']").prop('checked', false);
            }
        })
    })
</script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>