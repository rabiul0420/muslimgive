<?php $__env->startSection('content'); ?>

    <div class="container">
    <div class="page-slider margin-bottom-40 margin-top-40">
        <div class="row">
            <div class="col-md-8">
                <div id="carousel-example-generic" class="carousel slide carousel-slider">
                    <!-- Indicators -->
                    <ol class="carousel-indicators carousel-indicators-frontend">
                        <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=>$slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li data-target="#carousel-example-generic" data-slide-to="<?php echo e($k); ?>"
                                class="<?php echo e(($k==0)?'active':''); ?>"></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ol>


                    <div class="carousel-inner" role="listbox">
                        <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=>$slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div style="background-image: url(<?php echo e($slider->image); ?>); background-repeat: no-repeat; background-size: cover; background-position: center;"
                                 class="item carousel-item-eight <?php echo e(($k==0)?'active':''); ?>">
                            </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                    <!-- Controls -->
                        <a class="left carousel-control carousel-control-shop carousel-control-frontend"
                           href="#carousel-example-generic" role="button" data-slide="prev">
                            <i class="fa fa-angle-left" aria-hidden="true"></i>
                        </a>
                        <a class="right carousel-control carousel-control-shop carousel-control-frontend"
                           href="#carousel-example-generic" role="button" data-slide="next">
                            <i class="fa fa-angle-right" aria-hidden="true"></i>
                        </a>
                    </div>
                </div>
            </div>
            <div class="col-md-4">


                <div class="user_card">

                    <div class="d-flex justify-content-center form_container">
                         <h2>Login Form</h2>
                        <form method="post" action="<?php echo e(url('login')); ?>">
                            <?php echo e(csrf_field()); ?>

                            <div class="form-group">
                                <input type="text" name="email" required value="<?php echo e(old('email')); ?>" class="form-control input_user" value="" placeholder="username">
                            </div>
                            <div class="form-group">
                                <input type="password"  type="password" name="password" required class="form-control input_pass" value="" placeholder="password">
                            </div>
                            <div class="form-group">
                                <button type="submit" name="button" class="btn login_btn">Login</button>
                            </div>
                        </form>
                    </div>

                    <div class="mt-4">
                        <div class="d-flex justify-content-center links">
                            Don't have an account? <a href="<?php echo e(url('register')); ?>" class="ml-2">Sign Up</a>
                        </div>
                        <div class="d-flex justify-content-center links forgot-password">
                            <a href="<?php echo e(url('password/reset')); ?>">Forget Password?</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    </div>
    <div class="container">
        <h2>Our Training Services</h2>
        <div class="row margin-bottom-40">
            <?php $__currentLoopData = $training; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $single): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-4 col-xs-12">
                    <div class="well training-course"><a
                                href="<?php echo e(url('training/'.Illuminate\Support\Str::slug($single->title, '-'))); ?>"><img
                                    class="img-responsive" src="<?php echo e(url($single->image)); ?>"></a>
                        <h4>
                            <a href="<?php echo e(url('training/'.Illuminate\Support\Str::slug($single->title, '-'))); ?>"><?php echo e($single->title); ?></a>
                        </h4>
                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum
                            has been the industry's standard dummy text ever since the 1500s</p>
                        <p><a href="<?php echo e(url('training/'.Illuminate\Support\Str::slug($single->title, '-'))); ?>"><i
                                        style="padding: 8px 12px; border-radius: 50%; border: 2px solid #64aed9;"
                                        class="fa fa-angle-right"></i> Learn More</a></p>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
    <div style="width: 100%; background: #f1f1f1; padding: 50px 0 40px 0;">
        <div class="container">
                <div class="row">
                    <div class="col-md-12 col-lg-12">
                        <h2 class="text-left text-uppercase">Job Categories</h2>
                    </div>
                </div>
                <div class="clearfix">&nbsp;</div>
                <div class="clearfix">&nbsp;</div>
                <div class="category-list">
                    <div class="row">
                        <div class="col-md-4 col-lg-4">
                            <ul>
                                <?php $__currentLoopData = $job_category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($key%3==0 && $category->jobs->count()): ?>
                                    <li>
                                        <a href="<?php echo e(url('job-category/'.$category->id)); ?>" title="<?php echo e($category->title); ?>"><i class="fa fa-angle-right"></i>
                                            <?php echo e($category->title); ?> <span>(<?php echo e($category->jobs->count()); ?>)</span></a>
                                    </li>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>

                        <div class="col-md-4 col-lg-4">
                            <ul>
                                <?php $__currentLoopData = $job_category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($key%3==1 && $category->jobs->count()): ?>
                                        <li>
                                            <a href="<?php echo e(url('job-category/'.$category->id)); ?>" title="<?php echo e($category->title); ?>"><i class="fa fa-angle-right"></i>
                                                <?php echo e($category->title); ?> <span>(<?php echo e($category->jobs->count()); ?>)</span></a>
                                        </li>
                                    <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                        <div class="col-md-4 col-lg-4e">
                            <ul>
                                <?php $__currentLoopData = $job_category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($key%3==2 && $category->jobs->count()): ?>
                                        <li>
                                            <a href="<?php echo e(url('job-category/'.$category->id)); ?>" title="<?php echo e($category->title); ?>"><i class="fa fa-angle-right"></i>
                                                <?php echo e($category->title); ?> <span>(<?php echo e($category->jobs->count()); ?>)</span></a>
                                        </li>
                                    <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </ul>
                        </div>
                </div>
            </div>
        </div>
    </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>