<?php $__env->startSection('content'); ?>
    <div class="main">
        <div class="container">
            <ul class="breadcrumb">
                <li><a href="<?php echo e(url('')); ?>">Home</a></li>
                <li class="active">Login</li>
            </ul>
            <!-- BEGIN SIDEBAR & CONTENT -->
            <div class="row margin-bottom-40">
                <!-- BEGIN SIDEBAR -->
                <div class="sidebar col-md-3 col-sm-3">

                </div>
                <!-- END SIDEBAR -->

                <!-- BEGIN CONTENT -->
                <div class="col-md-9 col-sm-9">
                    <h1>Login</h1>
                    <?php if(Session::has('message')): ?>
                        <div class="alert alert-success" role="alert">
                           <?php echo e(Session::get('message')); ?>

                        </div>
                    <?php endif; ?>
                    <?php if($errors->has('email')): ?>
                        <div class="alert alert-danger">
                            <?php echo e($errors->first('email')); ?>

                        </div>
                    <?php endif; ?>
                    <div class="content-form-page">
                        <div class="row">
                            <div class="col-md-7 col-sm-7">
                                <form class="form-horizontal form-without-legend" method="post" action="<?php echo e(url('login')); ?>">
                                    <?php echo e(csrf_field()); ?>

                                    <div class="form-group">
                                        <label for="email" class="col-lg-4 control-label">Email <span class="require">*</span></label>
                                        <div class="col-lg-8">
                                            <input type="text" name="email" required value="<?php echo e(old('email')); ?>" class="form-control" id="email">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="password" class="col-lg-4 control-label">Password <span class="require">*</span></label>
                                        <div class="col-lg-8">
                                            <input type="password" name="password" required class="form-control" id="password">
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-lg-8 col-md-offset-4 padding-left-0">
                                            <a href="<?php echo e(url('password/reset')); ?>">Forget Password?</a>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-lg-8 col-md-offset-4 padding-left-0 padding-top-20">
                                            <button type="submit" class="btn btn-primary">Login</button>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-lg-8 col-md-offset-4 padding-left-0 padding-top-10 padding-right-30">
                                            <hr>
                                            
                                        </div>
                                    </div>
                                </form>
                            </div>
                            <div class="col-md-4 col-sm-4 pull-right">

                            </div>
                        </div>
                    </div>
                </div>
                <!-- END CONTENT -->
            </div>
            <!-- END SIDEBAR & CONTENT -->
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>