<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class CharityCa4 extends Model
{
    protected $table='charities_ca4';

}
